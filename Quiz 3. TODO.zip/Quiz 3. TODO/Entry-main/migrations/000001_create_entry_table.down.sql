-- Filename: migrations/000001_create_entry_table.down.sql

DROP TABLE IF EXISTS entries;